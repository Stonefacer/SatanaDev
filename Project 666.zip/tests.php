<?php


require "libs/DBCommon.php";


//die(GetPHPSESID("Stoneface", "Stoneface"));
//die(LogOut("e3a728e3de56008b72100a5c785e1c4d"));
//die(CheckLogin("Stoneface"));
//die(Registration("Test", "Test", "10"));
//die(GetFriends(1));
die(AddFriend(1, 0, "test"));
?>